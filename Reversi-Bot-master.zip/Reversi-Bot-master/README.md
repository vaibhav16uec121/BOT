# Reversi-Bot
A  Reversi Game playing bot implemented as a part of the Hackerearth July Bot Challenge.

It was ranked first in India and Eight in Global ranking. Implements AI game playing algorithms from scratch in C++ and uses min-max algorithms with several optimizations for quick generation of moves.
It is Augmented with complex hand-crafted static evaluation function.
